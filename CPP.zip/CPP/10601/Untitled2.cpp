#include <iostream>
using namespace std;

int main()
{
	cout << "AAA測試";
}